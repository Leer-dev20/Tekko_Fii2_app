# 🚀 Guide d'Installation - TEKKO-FII2

## Configuration Système

### Prérequis Techniques
- **PHP** : 7.4 ou supérieur
- **MySQL/MariaDB** : 5.7 ou supérieur  
- **Apache** : avec mod_rewrite activé (pour les URLs propres)
- **Laragon** (recommandé) pour l'environnement de développement

## Installation Pas à Pas

### 1️⃣ Configuration de la Base de Données

#### Avec Laragon/phpMyAdmin:
1. Ouvrez **phpMyAdmin** via Laragon
2. Créez une nouvelle base de données: `tekko_fii`
3. Sélectionnez la base de données
4. Allez dans l'onglet **"Importer"**
5. Choisissez le fichier **`database.sql`** dans le dossier racine
6. Cliquez sur **"Exécuter"**

#### Ou via Terminal/Invite de Commande:
```bash
mysql -u root -p < database.sql
```
*(Appuyez sur Entrée si pas de mot de passe)*

### 2️⃣ Configuration PHP

Éditez le fichier `app/config/config.php`:

```php
<?php
// Paramètres de la base de données
define('DB_HOST', 'localhost');      // Hôte MySQL
define('DB_USER', 'root');            // Utilisateur MySQL
define('DB_PASS', '');                // Mot de passe MySQL
define('DB_NAME', 'tekko_fii');       // Nom de la BD

// Paramètres de l'application
define('APP_URL', 'http://localhost/Tekko-Fii2');
```

⚠️ **Important**: Adapter les paramètres à votre environnement local

### 3️⃣ Activation d'Apache mod_rewrite (Optionnel)

Pour utiliser les URLs propres (ex: `/projet` au lieu de `/projet.php`):

#### Avec Laragon:
- La réécriture d'URL est automatiquement activée

#### Avec XAMPP:
1. Ouvrez `C:\xampp\apache\conf\httpd.conf`
2. Cherchez la ligne: `#LoadModule rewrite_module modules/mod_rewrite.so`
3. Enlevez le `#` pour la décommenter
4. Redémarrez Apache

### 4️⃣ Vérification de l'Installation

#### Via Laragon:
1. Clic droit sur le dossier `Tekko-Fii2` → **"Open in Browser"**
2. Ou accédez à: `http://localhost/Tekko-Fii2/public/index.php`

#### Via Apache classique:
- Placez le dossier dans `C:\xampp\htdocs\Tekko-Fii2`
- Accédez à: `http://localhost/Tekko-Fii2/public/index.php`

### 5️⃣ Permissions des Fichiers

Assurez-vous que les permissions sont correctes:

```bash
# Linux/Mac
chmod -R 755 /path/to/Tekko-Fii2
chmod -R 775 /path/to/Tekko-Fii2/app
chmod -R 775 /path/to/Tekko-Fii2/public
```

## Structure des Répertoires

```
Tekko-Fii2/
├── app/                    # Code applicatif
│   ├── config/
│   │   └── config.php     ← À modifier avec vos ID de BD
│   ├── controllers/
│   ├── models/
│   └── includes/
├── public/                # Point d'entrée (à ouvrir dans le navigateur)
│   ├── index.php
│   ├── connexion.php
│   ├── inscrire.php
│   └── ...autres pages
├── img/                   # Images du projet
├── database.sql          # À importer dans MySQL
├── README.md
└── INSTALL.md            # Ce fichier
```

## 🧪 Test de l'Installation

Après avoir complété les étapes ci-dessus:

1. **Accédez à la page d'accueil**
   ```
   http://localhost/Tekko-Fii2/public/index.php
   ```

2. **Testez l'inscription**
   - Cliquez sur "S'inscrire"
   - Remplissez le formulaire
   - Vérifiez que les données sont enregistrées dans la BD

3. **Testez la connexion**
   - Allez à "Se connecter"
   - Utilisez les identifiants créés précédemment

## ⚠️ Dépannage Courant

### Erreur: "Connection refused"
**Cause**: MySQL n'est pas démarré
- **Solution**: Démarrer le service MySQL via Laragon ou Services Windows

### Erreur: "SQLSTATE[28000]"  
**Cause**: Mauvais identifiants de base de données
- **Solution**: Vérifier `app/config/config.php` et adapter les paramètres

### Erreur: "File not found 404"
**Cause**: Mauvaise URL ou chemin incorrect
- **Solution**: Vérifier l'URL et la structure des répertoires

### Les images ne s'affichent pas
**Cause**: Chemin relatif incorrect
- **Solution**: Vérifier le dossier `img/` et les chemins dans les views

## 🔐 Configuration de Sécurité (Important!)

### Avant de mettre en production:

1. **Changer les authentifiants BD**
   ```php
   define('DB_USER', 'tekko_user');
   define('DB_PASS', 'motdepasse_complexe');
   ```

2. **Créer un utilisateur MySQL dédié**
   ```sql
   CREATE USER 'tekko_user'@'localhost' IDENTIFIED BY 'motdepasse_complexe';
   GRANT ALL PRIVILEGES ON tekko_fii.* TO 'tekko_user'@'localhost';
   ```

3. **Désactiver l'affichage d'erreurs en production**
   ```php
   ini_set('display_errors', 0);
   error_reporting(E_ALL);
   ```

4. **Configurer HTTPS/SSL** (recommandé)

5. **Mettre en place les headers de sécurité**

## 📚 Ressources Utiles

- [Documentation PHP](https://www.php.net)
- [Documentation MySQL](https://dev.mysql.com)
- [Tailwind CSS](https://tailwindcss.com)
- [Remix Icon](https://remixicon.com)

## 📞 Support

Pour toute question lors de l'installation:
1. Consultez le `README.md` 
2. Vérifiez les logs d'erreur PHP
3. Consultez les logs MySQL

---

**Installation Date**: 9 février 2026  
**Version**: 1.0.0 Beta
