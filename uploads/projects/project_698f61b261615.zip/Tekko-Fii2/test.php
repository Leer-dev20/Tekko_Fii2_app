<?php
/**
 * test.php - Fichier de test pour vérifier l'installation
 * 
 * Accédez à: http://localhost/Tekko-Fii2/test.php
 */

// Initialiser le test
echo "<!DOCTYPE html>";
echo "<html lang='fr'>";
echo "<head>";
echo "<meta charset='UTF-8'>";
echo "<meta name='viewport' content='width=device-width, initial-scale=1.0'>";
echo "<title>Test Installation Tekko-Fii2</title>";
echo "<script src='https://cdn.tailwindcss.com'></script>";
echo "</head>";
echo "<body class='bg-gradient-to-br from-blue-50 to-indigo-100 min-h-screen p-8'>";
echo "<div class='max-w-4xl mx-auto'>";

// Titre
echo "<div class='bg-white rounded-lg shadow-lg p-8 mb-8'>";
echo "<h1 class='text-4xl font-bold text-gray-900 mb-2'>✅ Test Installation Tekko-Fii2</h1>";
echo "<p class='text-gray-600'>Vérification de la configuration de l'application</p>";
echo "</div>";

// Tableau de résultats
echo "<div class='space-y-4'>";

// Test 1: Version PHP
echo "<div class='bg-white rounded-lg shadow p-6 border-l-4 border-blue-500'>";
echo "<div class='flex justify-between items-center'>";
echo "<div>";
echo "<h3 class='text-lg font-semibold'>PHP Version</h3>";
echo "<p class='text-gray-600'>Vérifie que PHP 7.4+ est installé</p>";
echo "</div>";

if (version_compare(PHP_VERSION, '7.4', '>=')) {
    echo "<div class='text-right'>";
    echo "<span class='bg-green-100 text-green-800 px-4 py-2 rounded-full font-semibold'>✓ OK</span>";
    echo "<p class='text-sm text-gray-600 mt-2'>" . PHP_VERSION . "</p>";
    echo "</div>";
} else {
    echo "<div class='text-right'><span class='bg-red-100 text-red-800 px-4 py-2 rounded-full font-semibold'>✗ ERREUR</span></div>";
}
echo "</div>";
echo "</div>";

// Test 2: Extensions PHP
$extensions = ['PDO', 'pdo_mysql', 'mbstring', 'json'];
$allExtensionsLoaded = true;
foreach ($extensions as $ext) {
    if (!extension_loaded($ext)) {
        $allExtensionsLoaded = false;
        break;
    }
}

echo "<div class='bg-white rounded-lg shadow p-6 border-l-4 border-blue-500'>";
echo "<div class='flex justify-between items-center'>";
echo "<div>";
echo "<h3 class='text-lg font-semibold'>Extensions PHP</h3>";
echo "<p class='text-gray-600'>Vérifie que les extensions requises sont chargées</p>";
echo "</div>";

if ($allExtensionsLoaded) {
    echo "<div class='text-right'>";
    echo "<span class='bg-green-100 text-green-800 px-4 py-2 rounded-full font-semibold'>✓ OK</span>";
    echo "<p class='text-sm text-gray-600 mt-2'>PDO, PDO MySQL, MBString, JSON</p>";
    echo "</div>";
} else {
    echo "<div class='text-right'>";
    echo "<span class='bg-red-100 text-red-800 px-4 py-2 rounded-full font-semibold'>✗ ERREUR</span>";
    echo "</div>";
}
echo "</div>";
echo "</div>";

// Test 3: Fichiers de configuration
echo "<div class='bg-white rounded-lg shadow p-6 border-l-4 border-blue-500'>";
echo "<div class='flex justify-between items-center'>";
echo "<div>";
echo "<h3 class='text-lg font-semibold'>Fichiers Requis</h3>";
echo "<p class='text-gray-600'>Vérifie que tous les fichiers existent</p>";
echo "</div>";

$files = [
    'app/config/config.php',
    'app/includes/Database.php',
    'app/includes/functions.php',
    'app/includes/layout.php',
    'app/models/User.php',
    'app/models/Project.php',
    'app/controllers/AuthController.php',
    'public/index.php',
    'public/connexion.php',
    'public/inscrire.php',
];

$allFilesExist = true;
foreach ($files as $file) {
    if (!file_exists(__DIR__ . '/' . $file)) {
        $allFilesExist = false;
        break;
    }
}

if ($allFilesExist) {
    echo "<div class='text-right'>";
    echo "<span class='bg-green-100 text-green-800 px-4 py-2 rounded-full font-semibold'>✓ OK</span>";
    echo "<p class='text-sm text-gray-600 mt-2'>Tous les fichiers sont présents</p>";
    echo "</div>";
} else {
    echo "<div class='text-right'>";
    echo "<span class='bg-red-100 text-red-800 px-4 py-2 rounded-full font-semibold'>✗ ERREUR</span>";
    echo "</div>";
}
echo "</div>";
echo "</div>";

// Test 4: Configuration Base de Données
echo "<div class='bg-white rounded-lg shadow p-6 border-l-4 border-purple-500'>";
echo "<div>";
echo "<h3 class='text-lg font-semibold mb-4'>Configuration Base de Données</h3>";

require_once __DIR__ . '/app/config/config.php';

echo "<div class='space-y-2 text-sm'>";
echo "<p><strong>Host:</strong> <code class='bg-gray-100 px-2 py-1 rounded'>" . DB_HOST . "</code></p>";
echo "<p><strong>Database:</strong> <code class='bg-gray-100 px-2 py-1 rounded'>" . DB_NAME . "</code></p>";
echo "<p><strong>URL APP:</strong> <code class='bg-gray-100 px-2 py-1 rounded'>" . APP_URL . "</code></p>";
echo "</div>";

echo "<div class='mt-4 p-4 bg-yellow-50 border border-yellow-200 rounded text-gray-700'>";
echo "<strong>⚠️ À faire:</strong>";
echo "<ul class='list-disc ml-5 mt-2'>";
echo "<li>Créer la base de données 'tekko_fii'</li>";
echo "<li>Importer le fichier <code>database.sql</code></li>";
echo "<li>Vérifier les identifiants MySQL</li>";
echo "</ul>";
echo "</div>";

echo "</div>";
echo "</div>";

// Lien vers les pages
echo "<div class='bg-white rounded-lg shadow-lg p-8 mt-8'>";
echo "<h2 class='text-2xl font-bold text-gray-900 mb-6'>Accès à l'Application</h2>";
echo "<div class='grid grid-cols-1 md:grid-cols-2 gap-4'>";

$links = [
    'Accueil' => 'public/index.php',
    'Inscription' => 'public/inscrire.php',
    'Connexion' => 'public/connexion.php',
    'Projets' => 'public/projet.php',
    'Développeurs' => 'public/developper.php',
    'Entreprise' => 'public/entreprise.php',
];

foreach ($links as $name => $url) {
    $fullUrl = APP_URL . '/' . $url;
    echo "<a href='$fullUrl' class='block p-4 bg-blue-500 hover:bg-blue-600 text-white rounded-lg font-semibold text-center transition'>";
    echo $name;
    echo "</a>";
}

echo "</div>";
echo "</div>";

// Prochaines étapes
echo "<div class='bg-white rounded-lg shadow-lg p-8 mt-8'>";
echo "<h2 class='text-2xl font-bold text-gray-900 mb-6'>✅ Prochaines Étapes</h2>";
echo "<ol class='space-y-3 list-decimal list-inside text-gray-700'>";
echo "<li><strong>Créer la base de données:</strong> Ouvrez phpMyAdmin et importez <code>database.sql</code></li>";
echo "<li><strong>Tester l'inscription:</strong> Créez un compte utilisateur</li>";
echo "<li><strong>Tester la connexion:</strong> Connectez-vous avec vos identifiants</li>";
echo "<li><strong>Consulter README.md:</strong> Pour plus de détails sur le projet</li>";
echo "<li><strong>Consulter INSTALL.md:</strong> Pour le guide d'installation complet</li>";
echo "</ol>";
echo "</div>";

// Footer
echo "<div class='text-center mt-8 text-gray-600'>";
echo "<p>Installation Tekko-Fii2 - Version 1.0.0 Beta</p>";
echo "<p class='text-sm mt-2'>Date: 9 février 2026</p>";
echo "</div>";

echo "</div>";
echo "</body>";
echo "</html>";
?>
