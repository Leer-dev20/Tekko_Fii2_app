<?php
require_once __DIR__ . '/../app/config/config.php';

$title = 'Tekko-Fii - Développeurs';
$content = __DIR__ . '/views/developper.html';
?>

<?php include __DIR__ . '/../app/includes/layout.php'; ?>
