<?php
require_once __DIR__ . '/../app/config/config.php';

$title = 'Tekko-Fii - Marketplace de projets de développeurs';
$content = __DIR__ . '/views/index.html';
?>

<?php include __DIR__ . '/../app/includes/layout.php'; ?>
