<?php
require_once __DIR__ . '/../app/config/config.php';

// Si formulaire soumis
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = filter_var($_POST['email'] ?? '', FILTER_SANITIZE_EMAIL);
    $password = $_POST['password'] ?? '';

    if (!$email || !$password) {
        $error = "Veuillez remplir tous les champs.";
    } elseif (!isValidEmail($email)) {
        $error = "Email invalide.";
    } else {
        // Vérifier dans la base de données (temporairement un exemple simple)
        // À faire: Créer un modèle User pour gérer la connexion
        $error = "Email ou mot de passe incorrect.";
    }

    if (isset($error)) {
        setFlash($error, 'error');
    } else {
        setFlash("Connexion réussie !", 'success');
        redirect('/public/index.php');
    }
}

$title = 'Tekko-Fii - Connexion';
$content = __DIR__ . '/views/connexion.html';
?>

<?php include __DIR__ . '/../app/includes/layout.php'; ?>
