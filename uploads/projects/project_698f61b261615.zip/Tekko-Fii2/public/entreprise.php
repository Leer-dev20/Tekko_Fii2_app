<?php
require_once __DIR__ . '/../app/config/config.php';

$title = 'Tekko-Fii - Entreprise';
$content = __DIR__ . '/views/entreprise.html';
?>

<?php include __DIR__ . '/../app/includes/layout.php'; ?>
