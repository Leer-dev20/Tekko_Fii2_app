<?php
require_once __DIR__ . '/../app/config/config.php';

// Déconnexion
session_destroy();
setFlash("Vous avez été déconnecté.", 'success');
redirect('/public/index.php');
