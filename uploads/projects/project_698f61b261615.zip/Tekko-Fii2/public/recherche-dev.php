<?php
require_once __DIR__ . '/../app/config/config.php';

$title = 'Tekko-Fii - Recherche de développeurs';
$content = __DIR__ . '/views/recherche-dev.html';
?>

<?php include __DIR__ . '/../app/includes/layout.php'; ?>
