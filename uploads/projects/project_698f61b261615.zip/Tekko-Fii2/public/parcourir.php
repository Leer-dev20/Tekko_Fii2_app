<?php
require_once __DIR__ . '/../app/config/config.php';

$title = 'Tekko-Fii - Parcourir les projets';
$content = __DIR__ . '/views/parcourir.html';
?>

<?php include __DIR__ . '/../app/includes/layout.php'; ?>
