<?php
require_once __DIR__ . '/../app/config/config.php';

// Si formulaire soumis
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $fullName = trim($_POST['fullName'] ?? '');
    $email = filter_var($_POST['email'] ?? '', FILTER_SANITIZE_EMAIL);
    $password = $_POST['password'] ?? '';
    $confirmPassword = $_POST['confirmPassword'] ?? '';
    $accountType = $_POST['accountType'] ?? '';
    $terms = isset($_POST['terms']);

    // Validations
    if (!$fullName || !$email || !$password || !$confirmPassword || !$accountType) {
        $error = "Veuillez remplir tous les champs.";
    } elseif (!isValidEmail($email)) {
        $error = "Email invalide.";
    } elseif (strlen($password) < 6) {
        $error = "Le mot de passe doit contenir au moins 6 caractères.";
    } elseif ($password !== $confirmPassword) {
        $error = "Les mots de passe ne correspondent pas.";
    } elseif (!$terms) {
        $error = "Vous devez accepter les conditions d'utilisation.";
    } else {
        // À faire: Créer un modèle User pour enregistrer l'utilisateur
        setFlash("Inscription réussie ! Connectez-vous maintenant.", 'success');
        redirect('/public/connexion.php');
    }

    if (isset($error)) {
        setFlash($error, 'error');
    }
}

$title = 'Tekko-Fii - Inscription';
$content = __DIR__ . '/views/inscrire.html';
?>

<?php include __DIR__ . '/../app/includes/layout.php'; ?>
