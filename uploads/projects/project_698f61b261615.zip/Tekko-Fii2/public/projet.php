<?php
require_once __DIR__ . '/../app/config/config.php';

$title = 'Tekko-Fii - Projets';
$content = __DIR__ . '/views/projet.html';
?>

<?php include __DIR__ . '/../app/includes/layout.php'; ?>
