# Tekko-Fii - Marketplace de Projets de Développeurs

Une plateforme web moderne qui connecte les développeurs avec les entreprises. Achetez et vendez des projets, trouvez des talents tech.

## 📋 Structure du Projet

```
Tekko-Fii2/
├── app/                    # Code applicatif
│   ├── config/            # Configuration
│   │   └── config.php     # Configuration de base de données et app
│   ├── includes/          # Fichiers inclus réutilisables
│   │   ├── Database.php   # Classe de gestion DB (PDO)
│   │   ├── functions.php  # Fonctions utilitaires
│   │   ├── layout.php     # Template principal (HTML)
│   │   └── header.php     # En-tête
│   ├── models/            # Modèles de données
│   │   ├── User.php       # Modèle utilisateur
│   │   └── Project.php    # Modèle projet
│   └── controllers/       # Contrôleurs (à développer)
│
├── public/                # Fichiers publiquement accessibles
│   ├── index.php          # Page d'accueil
│   ├── connexion.php      # Page de connexion
│   ├── inscrire.php       # Page d'inscription
│   ├── projet.php         # Liste des projets
│   ├── developper.php     # Annuaire des développeurs
│   ├── entreprise.php     # Page B2B
│   ├── recherche-dev.php  # Recherche avancée
│   ├── parcourir.php      # Navigation
│   ├── logout.php         # Déconnexion
│   ├── css/               # Feuilles de styles
│   ├── js/                # Scripts JavaScript
│   └── views/             # Fichiers template HTML
│
├── img/                   # Images et ressources
├── frontend/              # Fichiers HTML originaux
├── database.sql           # Script SQL pour initialiser la BD
├── .git/                  # Dépôt Git
└── README.md             # Ce fichier
```

## 🚀 Installation et Configuration

### Prérequis
- PHP 7.4+
- MySQL/MariaDB
- Serveur web (Apache/Nginx)
- Laragon (recommandé pour l'environnement local)

### Étapes d'installation

1. **Cloner le projet** (déjà fait - c:\laragon\www\Tekko-Fii2)

2. **Créer la base de données**
   ```sql
   -- Importer le fichier database.sql dans phpMyAdmin
   -- Ou via la ligne de commande:
   mysql -u root < database.sql
   ```

3. **Configurer la connexion BD**
   
   Editez `app/config/config.php`:
   ```php
   define('DB_HOST', 'localhost');
   define('DB_USER', 'root');
   define('DB_PASS', '');        // Votre mot de passe MySQL
   define('DB_NAME', 'tekko_fii');
   define('APP_URL', 'http://localhost/Tekko-Fii2');
   ```

4. **Accéder à l'application**
   
   Dans Laragon:
   - Clic droit sur le dossier → "Open in Browser"
   - Ou: `http://localhost/Tekko-Fii2/public/index.php`

## 📱 Pages Disponibles

| Page | Route | Description |
|------|-------|-------------|
| Accueil | `/public/index.php` | Landing page avec projets en vedette |
| Connexion | `/public/connexion.php` | Formulaire de connexion |
| Inscription | `/public/inscrire.php` | Création de compte |
| Projets | `/public/projet.php` | Catalogue de tous les projets |
| Développeurs | `/public/developper.php` | Annuaire des développeurs |
| Entreprise | `/public/entreprise.php` | Solutions B2B |
| Recherche Dev | `/public/recherche-dev.php` | Recherche avancée |
| Parcourir | `/public/parcourir.php` | Navigation par catégories |

## 🔧 Technologies Utilisées

- **Backend**: PHP 7.4+
- **Base de Données**: MySQL/MariaDB avec PDO
- **Frontend**: HTML5 + Tailwind CSS 3.4.16
- **Icônes**: Remix Icon 4.5.0
- **Fonts**: Google Fonts (Pacifico)

## 📝 Fonctionnalités Actuelles

✅ **Implémentées**:
- Structure MVC de base
- Authentification (login/register)
- Gestion de sessions
- Base de données complète
- Pages template responsive
- Fonctions utilitaires (hash, validation, etc.)

⏳ **À développer**:
- Contrôleurs complets
- API REST
- Système de paiement
- Système de messages
- Système de notation/avis
- Dashboard utilisateur
- Upload de fichiers
- Recherche full-text

## 🔒 Sécurité

- ✅ Hash des mots de passe (bcrypt)
- ✅ Protection CSRF (tokens)
- ✅ Validation des entrées
- ✅ Échappement des sorties (XSS protection)
- ⏳ À ajouter: Rate limiting, HTTPS SSL, etc.

## 📧 Configuration Email (À faire)

Pour activer les emails:
```php
// app/config/config.php
define('MAIL_HOST', '');
define('MAIL_PORT', '');
define('MAIL_USER', '');
define('MAIL_PASS', '');
```

## 🗄️ Structure Base de Données

- **users**: Utilisateurs développeurs et clients
- **projects**: Projets à vendre
- **orders**: Historique d'achats
- **reviews**: Avis et évaluations
- **conversations**: Conversations entre utilisateurs
- **messages**: Messages individuels
- **categories**: Catégories de projets

## 🎯 Prochaines Étapes

1. Créer les contrôleurs pour:
   - `AuthController` (login/register)
   - `ProjectController` (CRUD projets)
   - `UserController` (profils)
   - `OrderController` (achats)

2. Implémenter un système JWT ou session amélioré

3. Créer les pages de profil utilisateur

4. Ajouter les fonctionnalités de recherche/filtrage

5. Intégrer un système de paiement

## 📞 Support

Pour toute question sur le projet, consultez la documentation ou contactez l'équipe de développement.

---

**Dernière mise à jour**: 9 février 2026
