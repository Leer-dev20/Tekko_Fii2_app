<?php
// Configuration de l'application Tekko-Fii

// Paramètres de la base de données
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'tekko_fii');

// Paramètres de l'application
define('APP_NAME', 'Tekko-Fii');
define('APP_URL', 'http://localhost/Tekko-Fii2');
define('APP_LANG', 'fr');

// Configuration Tailwind
define('PRIMARY_COLOR', '#4285F4');
define('SECONDARY_COLOR', '#34A853');

// Démarrer la session
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Inclure les classes de base
require_once __DIR__ . '/../includes/Database.php';
require_once __DIR__ . '/../includes/functions.php';

// Connexion à la base de données
try {
    $db = new Database(DB_HOST, DB_USER, DB_PASS, DB_NAME);
} catch (Exception $e) {
    die("Erreur de connexion: " . $e->getMessage());
}
