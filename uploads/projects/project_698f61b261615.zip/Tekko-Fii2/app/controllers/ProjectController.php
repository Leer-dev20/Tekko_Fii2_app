<?php
/**
 * ProjectController - Gestion des projets
 */
require_once __DIR__ . '/../models/Project.php';

class ProjectController {
    private $projectModel;

    public function __construct($database) {
        $this->projectModel = new Project($database);
    }

    /**
     * Crée un nouveau projet
     */
    public function create($userId, $title, $description, $price, $category, $technologies = null) {
        // Validations
        if (!$title || !$description || !$price || !$category) {
            return [
                'success' => false,
                'message' => 'Tous les champs sont obligatoires.'
            ];
        }

        if (!is_numeric($price) || $price <= 0) {
            return [
                'success' => false,
                'message' => 'Le prix doit être un nombre positif.'
            ];
        }

        if (strlen($title) < 5) {
            return [
                'success' => false,
                'message' => 'Le titre doit contenir au moins 5 caractères.'
            ];
        }

        if (strlen($description) < 20) {
            return [
                'success' => false,
                'message' => 'La description doit contenir au moins 20 caractères.'
            ];
        }

        if ($this->projectModel->create($userId, $title, $description, $price, $category, $technologies)) {
            return [
                'success' => true,
                'message' => 'Projet créé avec succès !',
                'project_id' => $this->projectModel->db->lastInsertId()
            ];
        } else {
            return [
                'success' => false,
                'message' => 'Erreur lors de la création du projet.'
            ];
        }
    }

    /**
     * Obtient tous les projets
     */
    public function getAll($page = 1, $limit = 20) {
        $offset = ($page - 1) * $limit;
        $projects = $this->projectModel->getAllProjects($limit, $offset);
        $total = $this->projectModel->getTotalCount();

        return [
            'success' => true,
            'projects' => $projects,
            'total' => $total,
            'page' => $page,
            'per_page' => $limit,
            'total_pages' => ceil($total / $limit)
        ];
    }

    /**
     * Obtient un projet par ID
     */
    public function getById($id) {
        $project = $this->projectModel->getById($id);

        if ($project) {
            return [
                'success' => true,
                'project' => $project
            ];
        } else {
            return [
                'success' => false,
                'message' => 'Projet non trouvé.'
            ];
        }
    }

    /**
     * Obtient les projets d'un utilisateur
     */
    public function getUserProjects($userId) {
        $projects = $this->projectModel->getUserProjects($userId);

        return [
            'success' => true,
            'projects' => $projects,
            'count' => count($projects)
        ];
    }

    /**
     * Recherche des projets
     */
    public function search($keyword, $category = null, $page = 1, $limit = 20) {
        if (!$keyword) {
            return [
                'success' => false,
                'message' => 'Veuillez entrer un terme de recherche.'
            ];
        }

        $offset = ($page - 1) * $limit;
        $projects = $this->projectModel->search($keyword, $category, $limit, $offset);

        return [
            'success' => true,
            'projects' => $projects,
            'page' => $page,
            'per_page' => $limit
        ];
    }

    /**
     * Obtient les projets par catégorie
     */
    public function getByCategory($category, $page = 1, $limit = 20) {
        $offset = ($page - 1) * $limit;
        $projects = $this->projectModel->getByCategory($category, $limit, $offset);

        return [
            'success' => true,
            'projects' => $projects,
            'category' => $category,
            'page' => $page,
            'per_page' => $limit
        ];
    }

    /**
     * Obtient les projets en vedette
     */
    public function getFeatured($limit = 8) {
        $projects = $this->projectModel->getFeatured($limit);

        return [
            'success' => true,
            'projects' => $projects
        ];
    }

    /**
     * Met à jour un projet
     */
    public function update($id, $title, $description, $price, $category, $technologies = null) {
        // Validations
        if (!$title || !$description || !$price || !$category) {
            return [
                'success' => false,
                'message' => 'Tous les champs sont obligatoires.'
            ];
        }

        if ($this->projectModel->update($id, $title, $description, $price, $category, $technologies)) {
            return [
                'success' => true,
                'message' => 'Projet mis à jour avec succès !'
            ];
        } else {
            return [
                'success' => false,
                'message' => 'Erreur lors de la mise à jour.'
            ];
        }
    }

    /**
     * Supprime un projet
     */
    public function delete($id) {
        if ($this->projectModel->delete($id)) {
            return [
                'success' => true,
                'message' => 'Projet supprimé avec succès !'
            ];
        } else {
            return [
                'success' => false,
                'message' => 'Erreur lors de la suppression.'
            ];
        }
    }
}
