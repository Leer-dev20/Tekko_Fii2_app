<?php
/**
 * AuthController - Gestion de l'authentification
 */
require_once __DIR__ . '/../models/User.php';

class AuthController {
    private $userModel;

    public function __construct($database) {
        $this->userModel = new User($database);
    }

    /**
     * Traite l'inscription
     */
    public function register($name, $email, $password, $confirmPassword, $accountType) {
        // Validations
        if (!$name || !$email || !$password || !$confirmPassword || !$accountType) {
            return [
                'success' => false,
                'message' => 'Veuillez remplir tous les champs obligatoires.'
            ];
        }

        if (!isValidEmail($email)) {
            return [
                'success' => false,
                'message' => 'Email invalide.'
            ];
        }

        if (strlen($password) < 6) {
            return [
                'success' => false,
                'message' => 'Le mot de passe doit contenir au moins 6 caractères.'
            ];
        }

        if ($password !== $confirmPassword) {
            return [
                'success' => false,
                'message' => 'Les mots de passe ne correspondent pas.'
            ];
        }

        if ($this->userModel->userExists($email)) {
            return [
                'success' => false,
                'message' => 'Cet email est déjà utilisé.'
            ];
        }

        // Enregistrer l'utilisateur
        if ($this->userModel->register($name, $email, $password, $accountType)) {
            return [
                'success' => true,
                'message' => 'Inscription réussie ! Veuillez vous connecter.'
            ];
        } else {
            return [
                'success' => false,
                'message' => 'Erreur lors de l\'inscription. Réessayez.'
            ];
        }
    }

    /**
     * Traite la connexion
     */
    public function login($email, $password) {
        if (!$email || !$password) {
            return [
                'success' => false,
                'message' => 'Veuillez remplir tous les champs.'
            ];
        }

        if (!isValidEmail($email)) {
            return [
                'success' => false,
                'message' => 'Email invalide.'
            ];
        }

        $user = $this->userModel->login($email, $password);

        if ($user) {
            // Créer la session
            $_SESSION['user_id'] = $user->id;
            $_SESSION['user'] = [
                'id' => $user->id,
                'name' => $user->name,
                'email' => $user->email,
                'account_type' => $user->account_type
            ];

            return [
                'success' => true,
                'message' => 'Connexion réussie !',
                'user' => $_SESSION['user']
            ];
        } else {
            return [
                'success' => false,
                'message' => 'Email ou mot de passe incorrect.'
            ];
        }
    }

    /**
     * Déconnexion
     */
    public function logout() {
        session_destroy();
        return [
            'success' => true,
            'message' => 'Vous avez été déconnecté.'
        ];
    }

    /**
     * Vérifie si l'utilisateur est connecté
     */
    public function isAuthenticated() {
        return isLoggedIn();
    }

    /**
     * Obtient l'utilisateur actuel
     */
    public function getCurrentUser() {
        return getCurrentUser();
    }
}
