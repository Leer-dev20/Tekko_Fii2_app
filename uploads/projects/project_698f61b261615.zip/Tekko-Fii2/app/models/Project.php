<?php
/**
 * Modèle Project - Gestion des projets
 */
class Project {
    private $db;

    public function __construct($database) {
        $this->db = $database;
    }

    /**
     * Crée un nouveau projet
     */
    public function create($userId, $title, $description, $price, $category, $technologies = null) {
        $this->db->query(
            'INSERT INTO projects (user_id, title, description, price, category, technologies, created_at) 
             VALUES (:user_id, :title, :description, :price, :category, :technologies, NOW())'
        );
        
        $this->db->bind(':user_id', $userId);
        $this->db->bind(':title', $title);
        $this->db->bind(':description', $description);
        $this->db->bind(':price', $price);
        $this->db->bind(':category', $category);
        $this->db->bind(':technologies', $technologies);
        
        return $this->db->execute();
    }

    /**
     * Obtient tous les projets
     */
    public function getAllProjects($limit = 20, $offset = 0) {
        $this->db->query(
            'SELECT p.*, u.name as author FROM projects p
             JOIN users u ON p.user_id = u.id
             ORDER BY p.created_at DESC
             LIMIT :limit OFFSET :offset'
        );
        $this->db->bind(':limit', $limit, PDO::PARAM_INT);
        $this->db->bind(':offset', $offset, PDO::PARAM_INT);
        return $this->db->resultSet();
    }

    /**
     * Obtient un projet par ID
     */
    public function getById($id) {
        $this->db->query(
            'SELECT p.*, u.name as author, u.email FROM projects p
             JOIN users u ON p.user_id = u.id
             WHERE p.id = :id'
        );
        $this->db->bind(':id', $id);
        return $this->db->single();
    }

    /**
     * Obtient les projets d'un utilisateur
     */
    public function getUserProjects($userId) {
        $this->db->query('SELECT * FROM projects WHERE user_id = :user_id ORDER BY created_at DESC');
        $this->db->bind(':user_id', $userId);
        return $this->db->resultSet();
    }

    /**
     * Recherche des projets
     */
    public function search($keyword, $category = null, $limit = 20, $offset = 0) {
        $query = 'SELECT p.*, u.name as author FROM projects p
                  JOIN users u ON p.user_id = u.id
                  WHERE (p.title LIKE :keyword OR p.description LIKE :keyword OR p.technologies LIKE :keyword)';
        
        if ($category) {
            $query .= ' AND p.category = :category';
        }
        
        $query .= ' ORDER BY p.created_at DESC LIMIT :limit OFFSET :offset';
        
        $this->db->query($query);
        $this->db->bind(':keyword', '%' . $keyword . '%');
        
        if ($category) {
            $this->db->bind(':category', $category);
        }
        
        $this->db->bind(':limit', $limit, PDO::PARAM_INT);
        $this->db->bind(':offset', $offset, PDO::PARAM_INT);
        
        return $this->db->resultSet();
    }

    /**
     * Met à jour un projet
     */
    public function update($id, $title, $description, $price, $category, $technologies = null) {
        $this->db->query(
            'UPDATE projects SET title = :title, description = :description, 
             price = :price, category = :category, technologies = :technologies 
             WHERE id = :id'
        );
        
        $this->db->bind(':title', $title);
        $this->db->bind(':description', $description);
        $this->db->bind(':price', $price);
        $this->db->bind(':category', $category);
        $this->db->bind(':technologies', $technologies);
        $this->db->bind(':id', $id);
        
        return $this->db->execute();
    }

    /**
     * Supprime un projet
     */
    public function delete($id) {
        $this->db->query('DELETE FROM projects WHERE id = :id');
        $this->db->bind(':id', $id);
        return $this->db->execute();
    }

    /**
     * Compte les projets totaux
     */
    public function getTotalCount() {
        $this->db->query('SELECT COUNT(*) as count FROM projects');
        $result = $this->db->single();
        return $result->count;
    }

    /**
     * Obtient les projets en vedette
     */
    public function getFeatured($limit = 8) {
        $this->db->query(
            'SELECT p.*, u.name as author FROM projects p
             JOIN users u ON p.user_id = u.id
             ORDER BY p.views DESC
             LIMIT :limit'
        );
        $this->db->bind(':limit', $limit, PDO::PARAM_INT);
        return $this->db->resultSet();
    }

    /**
     * Obtient les projets par catégorie
     */
    public function getByCategory($category, $limit = 20, $offset = 0) {
        $this->db->query(
            'SELECT p.*, u.name as author FROM projects p
             JOIN users u ON p.user_id = u.id
             WHERE p.category = :category
             ORDER BY p.created_at DESC
             LIMIT :limit OFFSET :offset'
        );
        $this->db->bind(':category', $category);
        $this->db->bind(':limit', $limit, PDO::PARAM_INT);
        $this->db->bind(':offset', $offset, PDO::PARAM_INT);
        return $this->db->resultSet();
    }
}
