<?php
/**
 * Modèle User - Gestion des utilisateurs
 */
class User {
    private $db;

    public function __construct($database) {
        $this->db = $database;
    }

    /**
     * Enregistre un nouvel utilisateur
     */
    public function register($name, $email, $password, $accountType) {
        // Vérifier si l'email existe déjà
        if ($this->userExists($email)) {
            return false;
        }

        $hashedPassword = hashPassword($password);
        
        $this->db->query(
            'INSERT INTO users (name, email, password, account_type, created_at) 
             VALUES (:name, :email, :password, :account_type, NOW())'
        );
        
        $this->db->bind(':name', $name);
        $this->db->bind(':email', $email);
        $this->db->bind(':password', $hashedPassword);
        $this->db->bind(':account_type', $accountType);
        
        return $this->db->execute();
    }

    /**
     * Connecte un utilisateur
     */
    public function login($email, $password) {
        $this->db->query('SELECT * FROM users WHERE email = :email');
        $this->db->bind(':email', $email);
        $user = $this->db->single();

        if ($user && verifyPassword($password, $user->password)) {
            return $user;
        }
        
        return false;
    }

    /**
     * Obtient un utilisateur par ID
     */
    public function getUserById($id) {
        $this->db->query('SELECT id, name, email, account_type, created_at FROM users WHERE id = :id');
        $this->db->bind(':id', $id);
        return $this->db->single();
    }

    /**
     * Obtient un utilisateur par email
     */
    public function getUserByEmail($email) {
        $this->db->query('SELECT id, name, email, account_type, created_at FROM users WHERE email = :email');
        $this->db->bind(':email', $email);
        return $this->db->single();
    }

    /**
     * Vérifie si un utilisateur existe
     */
    public function userExists($email) {
        $this->db->query('SELECT id FROM users WHERE email = :email');
        $this->db->bind(':email', $email);
        $result = $this->db->single();
        return $result !== false;
    }

    /**
     * Met à jour le profil d'un utilisateur
     */
    public function updateProfile($id, $name, $bio = null) {
        $this->db->query('UPDATE users SET name = :name, bio = :bio WHERE id = :id');
        $this->db->bind(':name', $name);
        $this->db->bind(':bio', $bio);
        $this->db->bind(':id', $id);
        return $this->db->execute();
    }

    /**
     * Obtient tous les développeurs
     */
    public function getDevelopers($limit = 20, $offset = 0) {
        $this->db->query(
            'SELECT id, name, email, account_type, bio FROM users 
             WHERE account_type = "developer" 
             LIMIT :limit OFFSET :offset'
        );
        $this->db->bind(':limit', $limit, PDO::PARAM_INT);
        $this->db->bind(':offset', $offset, PDO::PARAM_INT);
        return $this->db->resultSet();
    }

    /**
     * Compte le nombre total de développeurs
     */
    public function getDeveloperCount() {
        $this->db->query('SELECT COUNT(*) as count FROM users WHERE account_type = "developer"');
        $result = $this->db->single();
        return $result->count;
    }

    /**
     * Change le mot de passe
     */
    public function changePassword($id, $newPassword) {
        $hashedPassword = hashPassword($newPassword);
        $this->db->query('UPDATE users SET password = :password WHERE id = :id');
        $this->db->bind(':password', $hashedPassword);
        $this->db->bind(':id', $id);
        return $this->db->execute();
    }
}
