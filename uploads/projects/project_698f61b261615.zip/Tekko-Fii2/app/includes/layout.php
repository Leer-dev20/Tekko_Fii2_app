<?php
$isLoggedIn = isLoggedIn();
$user = getCurrentUser();
$title = $title ?? 'Tekko-Fii - Marketplace de projets de développeurs';
?><!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo escape($title); ?></title>
    <link rel="shortcut icon" href="<?php echo APP_URL; ?>/img/Blue_Purple_Modern_Gradient_Computer_Service_and_Repair_Logo__1_-removebg-preview.png" type="image/x-icon">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Pacifico&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/remixicon@4.5.0/fonts/remixicon.css" rel="stylesheet">
    <script src="https://cdn.tailwindcss.com/3.4.16"></script>
    <script>tailwind.config={theme:{extend:{colors:{primary:'#4285F4',secondary:'#34A853'},borderRadius:{'none':'0px','sm':'4px',DEFAULT:'8px','md':'12px','lg':'16px','xl':'20px','2xl':'24px','3xl':'32px','full':'9999px','button':'8px'}}}}</script>
    <style>
        :where([class^="ri-"])::before { content: "\f3c2"; }
        body {
            font-family: 'Inter', sans-serif;
        }
        .hero-bg {
            background-image: url('<?php echo APP_URL; ?>/img/7401d6ed8df947c91eb40ae9801a54eb.jpg');
            background-size: cover;
            background-position: right center;
        }
        .hero-overlay {
            background: linear-gradient(90deg, rgba(255,255,255,0.95) 0%, rgba(255,255,255,0.9) 50%, rgba(255,255,255,0.5) 100%);
        }
        input:focus {
            outline: none;
        }
    </style>
</head>
<body class="bg-white min-h-screen flex flex-col">
    <!-- Header -->
    <header class="w-full py-4 px-6 flex justify-between items-center border-b border-gray-100">
        <div class="flex items-center">
            <a href="<?php echo APP_URL; ?>/public/index.php" class="text-2xl font-bold font-['Pacifico'] text-gray-900">Tekko-Fii</a>
        </div>
        <div class="flex items-center space-x-8">
            <nav class="hidden md:flex space-x-8">
                <a href="<?php echo APP_URL; ?>/public/projet.php" class="text-gray-800 hover:text-primary font-medium">Projets</a>
                <a href="<?php echo APP_URL; ?>/public/developper.php" class="text-gray-800 hover:text-primary font-medium">Développeurs</a>
                <a href="<?php echo APP_URL; ?>/public/entreprise.php" class="text-gray-800 hover:text-primary font-medium">Entreprise</a>
            </nav>
            <div class="flex items-center space-x-4">
                <?php if ($isLoggedIn): ?>
                    <span class="text-gray-800">Bienvenue, <?php echo escape($user['name'] ?? 'Utilisateur'); ?></span>
                    <a href="<?php echo APP_URL; ?>/public/logout.php" class="bg-red-500 text-white px-5 py-2 !rounded-button font-medium hover:bg-red-600 transition-colors whitespace-nowrap">Déconnexion</a>
                <?php else: ?>
                    <a href="<?php echo APP_URL; ?>/public/inscrire.php" class="text-gray-800 hover:text-primary font-medium whitespace-nowrap">S'inscrire</a>
                    <a href="<?php echo APP_URL; ?>/public/connexion.php" class="bg-primary text-white px-5 py-2 !rounded-button font-medium hover:bg-blue-600 transition-colors whitespace-nowrap">Se connecter</a>
                <?php endif; ?>
            </div>
        </div>
    </header>

    <!-- Flash Messages -->
    <?php if ($flash = getFlash()): ?>
        <div class="alert alert-<?php echo escape($flash['type']); ?> m-4 p-4 rounded border">
            <?php echo escape($flash['message']); ?>
        </div>
    <?php endif; ?>

    <!-- Main Content -->
    <main class="flex-grow">
        <?php include $content ?? null; ?>
    </main>

    <!-- Footer -->
    <footer class="bg-gray-900 text-white py-12 px-6 mt-12">
        <div class="container mx-auto">
            <div class="grid grid-cols-1 md:grid-cols-4 gap-10">
                <div>
                    <h3 class="text-xl font-bold mb-4 font-['Pacifico']">Tekko-Fii</h3>
                    <p class="text-gray-400 mb-6">La marketplace qui connecte développeurs et entreprises.</p>
                    <div class="flex space-x-4">
                        <a href="#" class="text-gray-400 hover:text-white">
                            <i class="ri-twitter-x-line ri-lg"></i>
                        </a>
                        <a href="#" class="text-gray-400 hover:text-white">
                            <i class="ri-linkedin-line ri-lg"></i>
                        </a>
                        <a href="#" class="text-gray-400 hover:text-white">
                            <i class="ri-github-line ri-lg"></i>
                        </a>
                    </div>
                </div>
                
                <div>
                    <h4 class="text-lg font-semibold mb-4">Liens rapides</h4>
                    <ul class="space-y-2">
                        <li><a href="#" class="text-gray-400 hover:text-white">Projets populaires</a></li>
                        <li><a href="#" class="text-gray-400 hover:text-white">Nouvelles arrivées</a></li>
                        <li><a href="#" class="text-gray-400 hover:text-white">Développeurs vérifiés</a></li>
                        <li><a href="#" class="text-gray-400 hover:text-white">Blog</a></li>
                    </ul>
                </div>
                
                <div>
                    <h4 class="text-lg font-semibold mb-4">Ressources</h4>
                    <ul class="space-y-2">
                        <li><a href="#" class="text-gray-400 hover:text-white">Documentation</a></li>
                        <li><a href="#" class="text-gray-400 hover:text-white">Guide du vendeur</a></li>
                        <li><a href="#" class="text-gray-400 hover:text-white">FAQ</a></li>
                        <li><a href="#" class="text-gray-400 hover:text-white">Support</a></li>
                    </ul>
                </div>
                
                <div>
                    <h4 class="text-lg font-semibold mb-4">Légal</h4>
                    <ul class="space-y-2">
                        <li><a href="#" class="text-gray-400 hover:text-white">Conditions d'utilisation</a></li>
                        <li><a href="#" class="text-gray-400 hover:text-white">Politique de confidentialité</a></li>
                        <li><a href="#" class="text-gray-400 hover:text-white">Licences</a></li>
                        <li><a href="#" class="text-gray-400 hover:text-white">Cookies</a></li>
                    </ul>
                </div>
            </div>
            
            <div class="border-t border-gray-800 mt-12 pt-8 flex flex-col md:flex-row justify-between items-center">
                <p class="text-gray-400 mb-4 md:mb-0">© 2025 Tekko-Fii. Tous droits réservés.</p>
                <div class="flex items-center space-x-4 text-gray-400">
                    <i class="ri-visa-line ri-lg"></i>
                    <i class="ri-mastercard-line ri-lg"></i>
                    <i class="ri-paypal-line ri-lg"></i>
                </div>
            </div>
        </div>
    </footer>
</body>
</html>
