<?php
$isLoggedIn = isLoggedIn();
$user = getCurrentUser();
?>
    <!-- Header -->
    <header class="w-full py-4 px-6 flex justify-between items-center border-b border-gray-100">
        <div class="flex items-center">
            <a href="<?php echo APP_URL; ?>/public/index.php" class="text-2xl font-bold font-['Pacifico'] text-gray-900">Tekko-Fii</a>
        </div>
        <div class="flex items-center space-x-8">
            <nav class="hidden md:flex space-x-8">
                <a href="<?php echo APP_URL; ?>/public/projet.php" class="text-gray-800 hover:text-primary font-medium">Projets</a>
                <a href="<?php echo APP_URL; ?>/public/developper.php" class="text-gray-800 hover:text-primary font-medium">Développeurs</a>
                <a href="<?php echo APP_URL; ?>/public/entreprise.php" class="text-gray-800 hover:text-primary font-medium">Entreprise</a>
            </nav>
            <div class="flex items-center space-x-4">
                <?php if ($isLoggedIn): ?>
                    <span class="text-gray-800">Bienvenue, <?php echo escape($user['name'] ?? 'Utilisateur'); ?></span>
                    <a href="<?php echo APP_URL; ?>/public/logout.php" class="bg-red-500 text-white px-5 py-2 !rounded-button font-medium hover:bg-red-600 transition-colors whitespace-nowrap">Déconnexion</a>
                <?php else: ?>
                    <a href="<?php echo APP_URL; ?>/public/inscrire.php" class="text-gray-800 hover:text-primary font-medium whitespace-nowrap">S'inscrire</a>
                    <a href="<?php echo APP_URL; ?>/public/connexion.php" class="bg-primary text-white px-5 py-2 !rounded-button font-medium hover:bg-blue-600 transition-colors whitespace-nowrap">Se connecter</a>
                <?php endif; ?>
            </div>
        </div>
    </header>
